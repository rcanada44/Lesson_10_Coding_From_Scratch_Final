


function GetIDCard(){
  var first = document.getElementById("firstName").value;
  var last = document.getElementById("lastName").value;
  var address = document.getElementById("address").value;
  var age = parseInt(document.getElementById("age").value);
  var phoneNumber = parseInt(document.getElementById("phoneNumber").value);
  var fullName = first + " " + last;

  document.getElementById("postfullName").innerHTML = "Full Name: " + fullName;
  document.getElementById("postaddress").innerHTML = "Address: " + address;
  
   
  var numberArray = [];
  numberArray.push(age, phoneNumber);

   for (var i=0; i < numberArray.length; i++){

         if(numberArray[i] <= 100){
           document.getElementById("postage").innerHTML = "Age: " + numberArray[i];
         } 
         else if(numberArray[i] > 100){
          document.getElementById("postphoneNumber").innerHTML = "phoneNumber: " + numberArray[i];
         }
        }
      }

      
 



        
  